﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicStoreWebsite.Models
{
    public class FavouritesViewModel
    {
        public List<MusicStoreWebsite.Models.ArtistViewModel> Artists { get; set; }

        public List<MusicStoreWebsite.Models.ArtistViewModel> Releases { get; set; }
    }
}