﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicStoreWebsite.Models
{
    public class ReleaseViewModel
    {
        public string ReleaseId { get; set; }
        public string Year { get; set; }
        public string Title { get; set; }
        public string ReleaseLabel { get; set; }
        public List<string> Tracks { get; set; }
        public int NumberOfTracks
        {
            get
            {
                return Tracks.Count();
            }
        }
    }
}
