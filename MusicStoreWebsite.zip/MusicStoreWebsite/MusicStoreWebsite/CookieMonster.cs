﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicStoreWebsite
{
    public static class CookieMonster
    {
        //public static List<MusicStoreWebsite.Models.ArtistViewModel> WriteCookie(string name, List<MusicStoreWebsite.Models.ArtistViewModel> value)
        //{
            
        //    var cookie = new HttpCookie(name, value);
        //    cookie.Expires = DateTime.UtcNow.AddDays(365);
        //    HttpContext.Current.Response.Cookies.Set(cookie);
        //}


        //public static List<MusicStoreWebsite.Models.ArtistViewModel> ReadCookie(string name, List<MusicStoreWebsite.Models.ArtistViewModel> defaultvalue)
        //{
        //    if (HttpContext.Current.Response.Cookies.AllKeys.Contains(name))
        //    {
        //        var cookie = HttpContext.Current.Response.Cookies[name];
        //        if (!string.IsNullOrEmpty(cookie.Value))
        //        {
        //            return cookie.Value;
        //        }
        //        else
        //        {
        //            return defaultvalue;
        //        }
        //    }

        //    if (HttpContext.Current.Request.Cookies.AllKeys.Contains(name))
        //    {
        //        var cookie = HttpContext.Current.Request.Cookies[name];
        //        if (!string.IsNullOrEmpty(cookie.Value))
        //        {
        //            return cookie.Value;
        //        }
        //        else
        //        {
        //            return defaultvalue;
        //        }
        //    }

        //    return null;
        //}
    }
}