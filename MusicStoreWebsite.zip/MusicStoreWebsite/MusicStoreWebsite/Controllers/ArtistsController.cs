﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MusicStoreWebsite.Controllers
{
    public class ArtistsController : Controller
    {
        // GET: Artists
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddToShortList(string mbid, string name)
        {
            try
            {
                var oModel = new MusicStoreWebsite.Models.ArtistViewModel
                {
                    id = mbid,
                    name = name,
                    type = "artist"
                };

                var ArtistList = GetMyShortList();
                ArtistList.Add(oModel);
                SaveMyShortList(ArtistList);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetShortList()
        {
            var oModel = new List<MusicStoreWebsite.Models.ArtistViewModel>();
            try
            {
                oModel = GetMyShortList();
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return PartialView(@"partials\\ShortListPartial", oModel);
        }


        #region "ShortList Session"
        private List<MusicStoreWebsite.Models.ArtistViewModel> GetMyShortList()
        {
            var oModel = new List<MusicStoreWebsite.Models.ArtistViewModel>();
            if (Session["MyShortList"] != null)
            {
                try
                {
                    oModel = Session["MyShortList"] as List<MusicStoreWebsite.Models.ArtistViewModel>;
                }
                catch (Exception ex)
                {
                    MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                }
            }
            return oModel;
        }

        private void SaveMyShortList(List<MusicStoreWebsite.Models.ArtistViewModel> value)
        {
            Session["MyShortList"] = value;
        }

        #endregion

    }
}