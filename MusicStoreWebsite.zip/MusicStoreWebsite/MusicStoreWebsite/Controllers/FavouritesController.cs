﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MusicStoreWebsite.Controllers
{
    public class FavouritesController : Controller
    {
        // GET: Favourites
        public ActionResult Index()
        {
            var oModel = new MusicStoreWebsite.Models.FavouritesViewModel();
            try
            {
                oModel.Artists = GetMyFavourites();
                oModel.Releases = GetMyReleases();
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return View(@"Index", oModel);
        }

        public ActionResult AddToFavourites(string mbid, string name)
        {
            try
            {
                var oModel = new MusicStoreWebsite.Models.ArtistViewModel
                {
                    id = mbid,
                    name = name,
                    type = "artist"
                };

                var ArtistList = GetMyFavourites();
                ArtistList.Add(oModel);
                SaveMyFavourites(ArtistList);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult RemoveFromFourites(string mbid, string name, string favtype)
        {
            try
            {
                if (favtype.ToLower() == "artist")
                {
                    var ArtistList = GetMyFavourites();
                    if (ArtistList.Count > 0)
                    {
                        var oModel = ArtistList.Where(x => x.id == mbid).FirstOrDefault();
                        if (oModel != null)
                        {
                            ArtistList.Remove(oModel);
                        }
                        SaveMyFavourites(ArtistList);
                    }
                }
                else
                {
                    var ArtistList = GetMyReleases();
                    if (ArtistList.Count > 0)
                    {
                        var oModel = ArtistList.Where(x => x.id == mbid).FirstOrDefault();
                        if (oModel != null)
                        {
                            ArtistList.Remove(oModel);
                        }
                        SavMyReleases(ArtistList);
                    }
                }
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }


        #region "Favourites Session"
        private List<MusicStoreWebsite.Models.ArtistViewModel> GetMyFavourites()
        {
            var oModel = new List<MusicStoreWebsite.Models.ArtistViewModel>();
            if (Session["MyFavourites"] != null)
            {
                try
                {
                    oModel = Session["MyFavourites"] as List<MusicStoreWebsite.Models.ArtistViewModel>;
                }
                catch(Exception ex)
                {
                    MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                }
            }
            return oModel;
        }

        private void SaveMyFavourites(List<MusicStoreWebsite.Models.ArtistViewModel> value)
        {
            Session["MyFavourites"] = value;
        }

        private List<MusicStoreWebsite.Models.ArtistViewModel> GetMyReleases()
        {
            var oModel = new List<MusicStoreWebsite.Models.ArtistViewModel>();
            if (Session["MyReleases"] != null)
            {
                try
                {
                    oModel = Session["MyReleases"] as List<MusicStoreWebsite.Models.ArtistViewModel>;
                }
                catch (Exception ex)
                {
                    MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                }
            }
            return oModel;
        }
        private void SavMyReleases(List<MusicStoreWebsite.Models.ArtistViewModel> value)
        {
            Session["MyReleases"] = value;
        }
        #endregion
    }
}