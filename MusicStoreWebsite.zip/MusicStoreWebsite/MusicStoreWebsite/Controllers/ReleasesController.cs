﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Xml.Linq;
using Hqub.MusicBrainz.API;
using Hqub.MusicBrainz.API.Entities;

namespace MusicStoreWebsite.Controllers
{
    public class ReleasesController : Controller
    {
        // GET: Releases
        public ActionResult Index()
        {
            return View();
        }

        public async Task<ActionResult> SearchArtist(string artistname)
        {
            var oModel = new Hqub.MusicBrainz.API.Entities.Collections.ArtistList();
            try
            {
                oModel = await Artist.SearchAsync(artistname);
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return PartialView(@"partials\\_ArtistListPartial", oModel);
        }

        public async Task<ActionResult> ReleasesByArtist(string artistId)
        {
            var oModel = new List<MusicStoreWebsite.Models.ReleaseViewModel>();
            try
            {
                var ReleasesList = await Release.BrowseAsync("artist", artistId, 10, 0, "media");
                foreach (var release in ReleasesList.Items)
                {
                    var oRelease = new MusicStoreWebsite.Models.ReleaseViewModel
                    {
                        Title = release.Title,
                        Year = FormatRelaseDate(release.Date),
                        ReleaseId = release.Id,
                        ReleaseLabel = FormatReleaseLabel(release.Labels),
                        Tracks = new List<string>()
                    };

                    var TrackList = await Recording.BrowseAsync("release", release.Id, 100);
                    foreach (var track in TrackList.Items)
                        oRelease.Tracks.Add(track.Title);

                    oModel.Add(oRelease);
                }
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return PartialView(@"partials\\_ReleaseListPartial", oModel);
        }
        
        public ActionResult AddToMyReleases(string mbid, string name)
        {
            try
            {
                var oModel = new MusicStoreWebsite.Models.ArtistViewModel
                {
                    id = mbid,
                    name = name,
                    type = "releases"
                };

                var ArtistList = GetMyReleases();
                ArtistList.Add(oModel);
                SavMyReleases(ArtistList);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult SearchArtistOld(string artistname)
        {
            String htmlString;
            try
            {
                HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(string.Format("http://musicbrainz.org/ws/2/artist/?query=artist:{0}", artistname));
                myReq.Headers.Clear();
                myReq.Method = "GET";
                myReq.KeepAlive = false;
                myReq.ProtocolVersion = HttpVersion.Version11;
                myReq.ContentType = "text/xml";
                myReq.Proxy = null;
                myReq.Credentials = null;
                myReq.UseDefaultCredentials = true;
                myReq.UserAgent = "Anything Goes";

                HttpWebResponse myResponse = (HttpWebResponse)myReq.GetResponse();
                StreamReader responseStream = new StreamReader(myResponse.GetResponseStream());
                htmlString = responseStream.ReadToEnd();

                responseStream.Close();
                myResponse.Close();

            }
            catch (WebException ex)
            {
                htmlString = ex.Message;
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            catch (Exception ex)
            {
                htmlString = ex.Message;
                MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
            return Json(htmlString, JsonRequestBehavior.AllowGet);
        }

        #region "Encapsulated"

        private List<MusicStoreWebsite.Models.ArtistViewModel> GetMyReleases()
        {
            var oModel = new List<MusicStoreWebsite.Models.ArtistViewModel>();
            if (Session["MyReleases"] != null)
            {
                try
                {
                    oModel = Session["MyReleases"] as List<MusicStoreWebsite.Models.ArtistViewModel>;
                }
                catch (Exception ex)
                {
                    MusicStoreWebsite.Utilities.ErrorHandling.ErrorHandler.SaveError(ex, MusicStoreWebsite.Constants.Application.Name, System.Reflection.MethodBase.GetCurrentMethod().Name);
                }
            }
            return oModel;
        }

        private void SavMyReleases(List<MusicStoreWebsite.Models.ArtistViewModel> value)
        {
            Session["MyReleases"] = value;
        }

        private string FormatRelaseDate(string value)
        {
            DateTime _ReleaseDate;
            if (DateTime.TryParse(value, out _ReleaseDate))
            {
                return _ReleaseDate.Year.ToString();
            }
            else {
                return value;
            }
        }

        private string FormatReleaseLabel(List<LabelInfo> value)
        {
            if (value.Count > 0)
            {
                var oLabel = value.Where(x => x.Label != null).FirstOrDefault();
                if(oLabel != null)
                {
                    return oLabel.Label.Name;
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
            }
        }
        #endregion
    }
}