﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MusicStoreWebsite
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.LowercaseUrls = true;
            routes.AppendTrailingSlash = true;

            routes.MapRoute(
                name: "GetShortList Route",
                url: "Artists/GetShortList/",
                defaults: new { controller = "Artists", action = "GetShortList" }
            );

            routes.MapRoute(
                name: "AddToShortList Route",
                url: "Artists/AddToShortList/{mbid}/{name}",
                defaults: new { controller = "Artists", action = "AddToShortList" }
            );

            routes.MapRoute(
               name: "AddToFavourites Route",
               url: "Favourites/AddToFavourites/{mbid}/{name}",
               defaults: new { controller = "Favourites", action = "AddToFavourites" }
           );

            routes.MapRoute(
               name: "RemoveFromFourites Route",
               url: "Favourites/RemoveFromFourites/{mbid}/{name}",
               defaults: new { controller = "Favourites", action = "RemoveFromFourites" }
           );

            routes.MapRoute(
               name: "SearchArtist Route",
               url: "Releases/SearchArtist/{artistname}",
               defaults: new { controller = "Releases", action = "SearchArtist" }
           );

            routes.MapRoute(
               name: "ReleasesByArtist Route",
               url: "Releases/ReleasesByArtist/{artistId}",
               defaults: new { controller = "Releases", action = "ReleasesByArtist" }
           );
            routes.MapRoute(
              name: "AddToMyReleases Route",
              url: "Releases/AddToMyReleases/{mbid}/{name}",
              defaults: new { controller = "FavouriReleasestes", action = "AddToMyReleases" }
          );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
