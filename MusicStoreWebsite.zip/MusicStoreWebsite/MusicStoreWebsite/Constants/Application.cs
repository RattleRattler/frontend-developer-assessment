﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MusicStoreWebsite.Constants
{
    public static class Application
    {
        public static string Name
        {
            get
            {
                return "Music Store Website";
            }
        }
    }
}