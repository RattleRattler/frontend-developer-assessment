﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MusicStoreWebsite.Utilities.ErrorHandling
{
    public static class ErrorHandler
    {
        public static void SaveError(Exception ex, string applicationname, [CallerMemberName] string CaughtInMethodName = "")
        {
            //TODO: Log error to database


            //TODO: Send error notification to developers
        }
    }
}
